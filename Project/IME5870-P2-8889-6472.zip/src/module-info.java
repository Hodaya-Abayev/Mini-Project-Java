/**
 * 
 */
/**
 * @author �����
 *
 */
module project {
	requires java.desktop;
	requires junit;
}