/**
 * 
 */
package unittests;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * @author ����
 *
 */
public class CylinderTests {

	/**
	 * Test method for {@link geometries.Cylinder#getNormal(Primitives.Point3D)}.
	 */
	@Test
	public void testGetNormal()
	{
		
	}

}
